#!/bin/bash
echo SMAC Interface Server
echo ---------------------
python -m http.server
